package hr.fer.demo;

import org.junit.Assert;
import org.junit.Test;

/**
 * Jednostavan primjer izrade junit testova.
 * 
 * @author marcupic
 */
public class UtilTest {

	@Test
	public void zaIsteBrojeve() {
		Assert.assertEquals(5, Util.getBigger(5, 5));
	}
	
	@Test
	public void zaPozitivneINegativne() {
		Assert.assertEquals(5, Util.getBigger(-7, 5));
	}
	
	@Test
	public void zaDvaNegativna() {
		Assert.assertEquals(-5, Util.getBigger(-7, -5));
	}
	
	@Test
	public void zaDvaPozitivna() {
		Assert.assertEquals(5, Util.getBigger(5, 1));
	}
	
}
