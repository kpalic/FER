package hr.fer.demo;

/**
 * Pomoćni razred koji nudi korisnu metodu za rad s cijelim brojevima.
 * Tu metodu ćemo testirati i to je jedini razlog njezina postojanja.
 * 
 * @author marcupic
 */
public class Util {

	/**
	 * Metoda vraća veći od primljena dva broja.
	 * 
	 * @param x prvi broj
	 * @param y drugi broj
	 * @return veći broj
	 */
	public static int getBigger(int x, int y) {
		return x>y ? x : y;
	}
	
}
