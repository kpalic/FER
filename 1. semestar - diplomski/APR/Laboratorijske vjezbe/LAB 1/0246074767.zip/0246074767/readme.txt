compile
g++ Matrice.cpp -o Matrice.exe

run 
Matrice.exe