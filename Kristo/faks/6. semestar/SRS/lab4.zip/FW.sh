#! /bin/sh
#
# Dodajte ili modificirajte pravila na oznacenim mjestima ili po potrebi (i zelji) na 
# nekom drugom odgovarajucem mjestu (pazite: pravila se obrađuju slijedno!)
#
IPT=/sbin/iptables

$IPT -P INPUT DROP
$IPT -P OUTPUT DROP
$IPT -P FORWARD DROP

$IPT -F INPUT
$IPT -F OUTPUT
$IPT -F FORWARD

$IPT -A INPUT   -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPT -A OUTPUT  -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPT -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT

#
# za potrebe testiranja dozvoljen je ICMP (ping i sve ostalo)
#
$IPT -A INPUT   -p icmp -j ACCEPT
$IPT -A FORWARD -p icmp -j ACCEPT
$IPT -A OUTPUT  -p icmp -j ACCEPT

#
# Primjer "anti spoofing" pravila na sucelju eth0
#
$IPT -A INPUT   -i eth0 -s 127.0.0.0/8  -j DROP
$IPT -A FORWARD -i eth0 -s 127.0.0.0/8  -j DROP
$IPT -A INPUT   -i eth0 -s 198.51.100.0/24  -j DROP
$IPT -A FORWARD -i eth0 -s 198.51.100.0/24  -j DROP
$IPT -A INPUT   -i eth0 -s 10.0.0.0/24  -j DROP
$IPT -A FORWARD -i eth0 -s 10.0.0.0/24  -j DROP

$IPT -A INPUT   -i eth0 -s 127.0.0.0/8  -j DROP
$IPT -A FORWARD -i eth0 -s 127.0.0.0/8  -j DROP
$IPT -A INPUT   -i eth0 -s 198.51.100.0/24  -j DROP
$IPT -A FORWARD -i eth0 -s 198.51.100.0/24  -j DROP
$IPT -A INPUT   -i eth0 -s 10.0.0.0/24  -j DROP
$IPT -A FORWARD -i eth0 -s 10.0.0.0/24  -j DROP

$IPT -A INPUT   -i eth1 -s 127.0.0.0/8  -j DROP
$IPT -A FORWARD -i eth1 -s 127.0.0.0/8  -j DROP
$IPT -A INPUT   -i eth1 -s 198.51.100.0/24  -j DROP
$IPT -A FORWARD -i eth1 -s 198.51.100.0/24  -j DROP
$IPT -A INPUT   -i eth1 -s 203.0.113.0/24  -j DROP
$IPT -A FORWARD -i eth1 -s 203.0.113.0/24  -j DROP

$IPT -A INPUT   -i eth2 -s 127.0.0.0/8  -j DROP
$IPT -A FORWARD -i eth2 -s 127.0.0.0/8  -j DROP
$IPT -A INPUT   -i eth2 -s 203.0.113.0/24  -j DROP
$IPT -A FORWARD -i eth2 -s 203.0.113.0/24  -j DROP
$IPT -A INPUT   -i eth2 -s 10.0.0.0/24  -j DROP
$IPT -A FORWARD -i eth2 -s 10.0.0.0/24  -j DROP

# Lan 3
$IPT -A FORWARD -s 10.0.0.100 -d 198.51.100.0/24 -j DROP
$IPT -A FORWARD -s 10.0.0.100 -d 203.0.113.0/24 -j DROP


# DMZ: 
# Web poslužitelju i DNS poslužitelju na čvoru www, koji se nalazi u demilitariziranoj zoni, se 
# može pristupiti s bilo koje adrese (iz Interneta i iz lokalne mreže). 
$IPT -A FORWARD -p TCP -d 198.51.100.10 --dport 80 -j ACCEPT
$IPT -A FORWARD -p UDP -d 198.51.100.10 --dport 53 -j ACCEPT
$IPT -A FORWARD -p TCP -d 198.51.100.10 --dport 53 -j ACCEPT

# SSH poslužitelju na čvoru www se može pristupiti samo iz lokalne mreže LAN. 
$IPT -A FORWARD -p TCP -s 10.0.0.0/24 -d 198.51.100.10 --dport 22 -j ACCEPT

# S www je dozvoljen pristup poslužitelju  database (LAN) na TCP portu 10000 te pristup DNS 
# poslužiteljima u Internetu (UDP i TCP port 53), a sve ostalo je zabranjeno. 
$IPT -A FORWARD -p TCP -s 198.51.100.10 -d 10.0.0.100 --dport 10000 -j ACCEPT
$IPT -A FORWARD -p TCP -s 198.51.100.10 -d 203.0.113.10 --dport 53 -j ACCEPT
$IPT -A FORWARD -p UDP -s 198.51.100.10 -d 203.0.113.10 --dport 53 -j ACCEPT
$IPT -A FORWARD -s 198.51.100.10 -j DROP

# Pristup svim ostalim adresama i poslužiteljima u DMZ je zabranjen. 



# LAN:

# Pristup SSH poslužitelju na čvoru database, koji se nalazi u lokalnoj mreži LAN, 
# dozvoljen je samo računalima iz mreže LAN. 
$IPT -A FORWARD -p TCP -s 10.0.0.0/24 -d 10.0.0.100 --dport 22 -j ACCEPT

# Pristup web poslužitelju na čvoru database (koji sluša na TCP portu 10000) 
# dozvoljen je  isključivo s računala www koje se nalazi u DMZ (i računalima 
# iz mreže LAN). 

# vec imamo gore. $IPT -A FORWARD -s 198.51.100.10 -d 10.0.0.100 -p TCP --dport 10000
$IPT -A FORWARD -p TCP -s 10.0.0.0/24 -d 10.0.0.100 --dport 10000

# S računala database je zabranjen pristup svim uslugama u Internetu i u DMZ. 

# stavljeno gore!

# S računala iz lokalne mreže (osim s database) se može pristupati svim računalima 
# u Internetu ali samo korištenjem protokola HTTP (tcp/80) i DNS (udp/53 i tcp/53). 
$IPT -A FORWARD -p TCP -s 10.0.0.0/24 -d 203.0.113.0/24 --dport 80 -j ACCEPT
$IPT -A FORWARD -p UDP -s 10.0.0.0/24 -d 203.0.113.0/24 --dport 53 -j ACCEPT
$IPT -A FORWARD -p TCP -s 10.0.0.0/24 -d 203.0.113.0/24 --dport 53 -j ACCEPT

# Pristup iz vanjske mreže u lokalnu LAN mrežu je zabranjen. 



# FW: 

# Na FW je pokrenut SSH poslužitelj kojem se može pristupiti samo iz lokalne 
# mreže i to samo s čvora PC. 
$IPT -A INPUT -p TCP -s 10.0.0.20 --dport 22 -j ACCEPT

# Pristup svim ostalim uslugama (portovima) na čvoru  FW je zabranjen.



# Internet: 

# Na čvoru server (u Internetu) su pokrenuti web poslužitelj i SSH 
# poslužitelj kojima se može pristupiti s bilo koje adrese.
$IPT -A FORWARD -p TCP -d 203.0.113.10 --dport 80 -j ACCEPT
$IPT -A FORWARD -p TCP -d 203.0.113.10 --dport 22 -j ACCEPT
