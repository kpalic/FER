# DOAS-projekt
dataset : https://www.kaggle.com/datasets/amaralibey/gsv-cities/data

izvorni kod sastoji se od:
    data
    -   skripte za particioniranje dataseta

    code
    -   resnet18 model (učenje i evaluacija)
    -   program za traženje optimalnih parametara resnet18 modela
    -   ispis tijekom učenja modela