import os

# Define the paths
train_path = os.path.join('training')
val_path = os.path.join('validation')
test_path = os.path.join('testing')

# Function to rename files
def rename_files(directory):
    all_files = []
    
    # Collect all files from the directory
    for root, _, files in os.walk(directory):
        for file in files:
            all_files.append(os.path.join(root, file))
    
    # Rename files
    for i, file_path in enumerate(all_files, 1):
        dir_name = os.path.dirname(file_path)
        file_name = os.path.basename(file_path)
        
        # Extract the city name from the file name
        city_name = file_name.split('_')[0]
        
        # Create new file name
        new_file_name = f"{i}_{city_name}{os.path.splitext(file_name)[1]}"
        new_file_path = os.path.join(dir_name, new_file_name)
        
        # Rename the file
        os.rename(file_path, new_file_path)
        print(f"Renamed {file_path} to {new_file_path}")

# Run the function for each directory
rename_files(train_path)
rename_files(val_path)
rename_files(test_path)