import os
from concurrent.futures import ThreadPoolExecutor

# Define the paths
train_path = os.path.join('training')
val_path = os.path.join('validation')
test_path = os.path.join('testing')

# Function to collect all files in a directory
def collect_files(directory):
    all_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            all_files.append(os.path.join(root, file))
    return all_files

# Function to rename a single file
def rename_file(file_path, index):
    dir_name = os.path.dirname(file_path)
    file_name = os.path.basename(file_path)
    
    # Extract the city name from the file name
    city_name = file_name.split('_')[0]
    
    # Create new file name
    new_file_name = f"{index}_{city_name}{os.path.splitext(file_name)[1]}"
    new_file_path = os.path.join(dir_name, new_file_name)
    
    # Rename the file
    os.rename(file_path, new_file_path)
    print(f"Renamed {file_path} to {new_file_path}")

# Function to rename files in a directory using ThreadPoolExecutor
def rename_files(directory):
    all_files = collect_files(directory)
    
    with ThreadPoolExecutor() as executor:
        futures = []
        for i, file_path in enumerate(all_files, 1):
            futures.append(executor.submit(rename_file, file_path, i))
        
        # Wait for all futures to complete
        for future in futures:
            future.result()

# Run the function for each directory
rename_files(train_path)
rename_files(val_path)
rename_files(test_path)
