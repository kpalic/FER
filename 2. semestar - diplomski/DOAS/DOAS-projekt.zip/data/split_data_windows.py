import os
import shutil
import random
from concurrent.futures import ThreadPoolExecutor

# Define the seed for reproducibility
random.seed(42)

# Define the paths
base_path = 'Images'
train_path = 'training'
val_path = 'validation'
test_path = 'testing'

# Create directories if they do not exist
os.makedirs(train_path, exist_ok=True)
os.makedirs(val_path, exist_ok=True)
os.makedirs(test_path, exist_ok=True)

# Function to split dataset
def split_dataset(base_path):
    tasks = []
    with ThreadPoolExecutor() as executor:
        for city in os.listdir(base_path):
            city_path = os.path.join(base_path, city)
            if os.path.isdir(city_path):
                images = os.listdir(city_path)
                random.shuffle(images)

                # Split the images
                train_split = int(0.7 * len(images))
                val_split = int(0.85 * len(images))

                for i, image in enumerate(images):
                    src_path = os.path.join(city_path, image)
                    
                    if i < train_split:
                        dest_path = os.path.join(train_path, image)
                    elif i < val_split:
                        dest_path = os.path.join(val_path, image)
                    else:
                        dest_path = os.path.join(test_path, image)
                    
                    tasks.append(executor.submit(shutil.copy, src_path, dest_path))


# Run the function
split_dataset(base_path)
