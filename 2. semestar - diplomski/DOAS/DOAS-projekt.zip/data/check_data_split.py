import os

# Define the paths
train_path = os.path.join('training')
val_path = os.path.join('validation')
test_path = os.path.join('testing')

# Function to count items in a directory
def count_items_in_dir(directory):
    return len([item for item in os.listdir(directory) if os.path.isfile(os.path.join(directory, item))])

# Count items in each directory
train_count = count_items_in_dir(train_path)
val_count = count_items_in_dir(val_path)
test_count = count_items_in_dir(test_path)

# Print the counts
print(f"Training Set: {train_count} items")
print(f"Validation Set: {val_count} items")
print(f"Testing Set: {test_count} items")

# Calculate and print the total number of items
total_count = train_count + val_count + test_count
print(f"Total Number of Items: {total_count}")
