import os
import time
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms, models
from PIL import Image
from tqdm import tqdm

# Postavke za reproducibilnost
random_seed = 42
torch.manual_seed(random_seed)

# Najbolji parametri
best_learning_rate = 0.0001
best_optimizer = 'Adam'
best_batch_size = 32
best_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
num_epochs = 50  # Povećan broj epoha kako bi Early Stopping imao smisla
patience = 5  # Broj epoha bez poboljšanja prije zaustavljanja

# Definiramo prilagođeni dataset
class CustomImageDataset(Dataset):
    def __init__(self, image_dir, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        self.image_paths = [os.path.join(image_dir, fname) for fname in os.listdir(image_dir)]
        self.labels = [fname.split('_')[1].split('.')[0] for fname in os.listdir(image_dir)]
        self.label_to_idx = {label: idx for idx, label in enumerate(set(self.labels))}
        self.idx_to_label = {idx: label for label, idx in self.label_to_idx.items()}

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = Image.open(img_path).convert("RGB")
        label = self.labels[idx]
        label_idx = self.label_to_idx[label]

        if self.transform:
            image = self.transform(image)

        return image, label_idx

# EarlyStopping klasa
class EarlyStopping:
    def __init__(self, patience=7, verbose=False, delta=0):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = float('inf')
        self.delta = delta

    def __call__(self, val_loss, model):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        '''Spremanje modela kada validation loss smanjen.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        torch.save(model.state_dict(), 'checkpoint.pt')
        self.val_loss_min = val_loss

# Funkcija za treniranje modela
def train_model(model, criterion, optimizer, scheduler, dataloaders, dataset_sizes, device, num_epochs, early_stopping):
    for epoch in range(num_epochs):
        start_time = time.time()
        print(f'Epoch {epoch}/{num_epochs - 1}')
        print('-' * 10)

        # Svaka epoha ima trening i validacijski dio
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()  # Postavi model u trening mod
            else:
                model.eval()   # Postavi model u evaluacijski mod

            running_loss = 0.0
            running_corrects = 0

            # Iteriramo kroz podatke
            for inputs, labels in tqdm(dataloaders[phase], desc=f'{phase} epoch {epoch + 1}/{num_epochs}'):
                inputs = inputs.to(device)
                labels = labels.to(device)

                # Nuliramo gradijente
                optimizer.zero_grad()

                # Forward
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    # Backward + optimizacija samo u trening fazi
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            if phase == 'train':
                scheduler.step()

            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print(f'{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')

            # Early stopping provjera samo na validation skupu
            if phase == 'val':
                early_stopping(epoch_loss, model)

        if early_stopping.early_stop:
            print("Early stopping")
            break
        
        end_time = time.time()
        epoch_time = end_time - start_time
        print(f"Epoch {epoch} completed in {epoch_time:.2f} seconds")

    # Vraćamo najbolji model
    model.load_state_dict(torch.load('checkpoint.pt'))
    return model

# Funkcija za evaluaciju modela
def evaluate_model(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    running_corrects = 0
    with torch.no_grad():
        for inputs, labels in tqdm(dataloader, desc='Evaluating'):
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)
    total_loss = running_loss / len(dataloader.dataset)
    total_acc = running_corrects.double() / len(dataloader.dataset)
    return total_loss, total_acc

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()

    # Definiramo putanje do podataka
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(base_dir, '..\\..', 'data'))
    train_dir = os.path.join(data_dir, 'training')
    val_dir = os.path.join(data_dir, 'validation')
    test_dir = os.path.join(data_dir, 'testing')

    # Kreiramo dataset i dataloader
    train_dataset = CustomImageDataset(train_dir, transform=best_transform)
    val_dataset = CustomImageDataset(val_dir, transform=best_transform)
    test_dataset = CustomImageDataset(test_dir, transform=best_transform)

    dataloaders = {
        'train': DataLoader(train_dataset, batch_size=best_batch_size, shuffle=True, num_workers=4, pin_memory=True),
        'val': DataLoader(val_dataset, batch_size=best_batch_size, shuffle=True, num_workers=4, pin_memory=True),
        'test': DataLoader(test_dataset, batch_size=best_batch_size, shuffle=True, num_workers=4, pin_memory=True)
    }

    dataset_sizes = {x: len(dataloaders[x].dataset) for x in ['train', 'val', 'test']}
    class_names = train_dataset.label_to_idx.keys()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    # Učitavamo predtreniran ResNet model
    model_ft = models.resnet18(pretrained=True)
    num_ftrs = model_ft.fc.in_features
    model_ft.fc = nn.Linear(num_ftrs, len(class_names))
    model_ft = model_ft.to(device)

    criterion = nn.CrossEntropyLoss()

    if best_optimizer == 'SGD':
        optimizer_ft = optim.SGD(model_ft.parameters(), lr=best_learning_rate, momentum=0.9)
    elif best_optimizer == 'Adam':
        optimizer_ft = optim.Adam(model_ft.parameters(), lr=best_learning_rate)

    scheduler = optim.lr_scheduler.StepLR(optimizer_ft, step_size=7, gamma=0.1)

    early_stopping = EarlyStopping(patience=patience, verbose=True)

    print(f"Training model with learning_rate={best_learning_rate}, optimizer={best_optimizer}, batch_size={best_batch_size}, transform={best_transform}")
    model_ft = train_model(model_ft, criterion, optimizer_ft, scheduler, dataloaders, dataset_sizes, device, num_epochs=num_epochs, early_stopping=early_stopping)

    # Evaluiramo model na trening, validacijskom i test skupu
    train_loss, train_acc = evaluate_model(model_ft, dataloaders['train'], criterion, device)
    val_loss, val_acc = evaluate_model(model_ft, dataloaders['val'], criterion, device)
    test_loss, test_acc = evaluate_model(model_ft, dataloaders['test'], criterion, device)

    print(f"Training Loss: {train_loss:.4f} Training Accuracy: {train_acc:.4f}")
    print(f"Validation Loss: {val_loss:.4f} Validation Accuracy: {val_acc:.4f}")
    print(f"Test Loss: {test_loss:.4f} Test Accuracy: {test_acc:.4f}")

    # Spremamo finalni model
    torch.save(model_ft.state_dict(), 'best_model.pth')
