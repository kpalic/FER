import os
import random
import csv
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset, Subset
from torchvision import datasets, models, transforms
from PIL import Image
from tqdm import tqdm
from sklearn.model_selection import train_test_split

# Postavke za reproducibilnost
random.seed(42)
torch.manual_seed(42)

# Definiramo parametre za eksperimentiranje
learning_rates = [0.001, 0.0001]
optimizers = ['SGD', 'Adam']
batch_sizes = [16, 32]
transformations = [
    transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.2),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
]
num_epochs = 5

# Definiramo prilagođeni dataset
class CustomImageDataset(Dataset):
    def __init__(self, image_dir, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        self.image_paths = [os.path.join(image_dir, fname) for fname in os.listdir(image_dir)]
        self.labels = [fname.split('_')[1].split('.')[0] for fname in os.listdir(image_dir)]
        self.label_to_idx = {label: idx for idx, label in enumerate(set(self.labels))}
        self.idx_to_label = {idx: label for label, idx in self.label_to_idx.items()}

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = Image.open(img_path).convert("RGB")
        label = self.labels[idx]
        label_idx = self.label_to_idx[label]

        if self.transform:
            image = self.transform(image)

        return image, label_idx

# Funkcija za treniranje modela
def train_model(model, criterion, optimizer, scheduler, dataloaders, dataset_sizes, device, num_epochs):
    for epoch in range(num_epochs):
        print(f'Epoch {epoch}/{num_epochs - 1}')
        print('-' * 10)

        # Svaka epoha ima trening i validacijski dio
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()  # Postavi model u trening mod
            else:
                model.eval()   # Postavi model u evaluacijski mod

            running_loss = 0.0
            running_corrects = 0

            # Iteriramo kroz podatke
            for inputs, labels in tqdm(dataloaders[phase], desc=f'{phase} epoch {epoch + 1}/{num_epochs}'):
                inputs = inputs.to(device)
                labels = labels.to(device)

                # Nuliramo gradijente
                optimizer.zero_grad()

                # Forward
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    # Backward + optimizacija samo u trening fazi
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            if phase == 'train':
                scheduler.step()

            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print(f'{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')

    return model

# Funkcija za evaluaciju modela
def evaluate_model(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    running_corrects = 0
    with torch.no_grad():
        for inputs, labels in tqdm(dataloader, desc='Evaluating'):
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)
    total_loss = running_loss / len(dataloader.dataset)
    total_acc = running_corrects.double() / len(dataloader.dataset)
    return total_loss, total_acc

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()

    # Definiramo putanje do podataka
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(base_dir, '..'))
    train_dir = os.path.join(data_dir, 'training')
    val_dir = os.path.join(data_dir, 'validation')
    test_dir = os.path.join(data_dir, 'testing')

    # Kreiramo dataset i dataloader za 5% podataka
    full_train_dataset = CustomImageDataset(train_dir, transform=None)
    full_val_dataset = CustomImageDataset(val_dir, transform=None)

    train_indices, _ = train_test_split(list(range(len(full_train_dataset))), test_size=0.95, random_state=42)
    val_indices, _ = train_test_split(list(range(len(full_val_dataset))), test_size=0.95, random_state=42)

    train_dataset = Subset(full_train_dataset, train_indices)
    val_dataset = Subset(full_val_dataset, val_indices)

    results = []

    for lr in learning_rates:
        for opt in optimizers:
            for batch_size in batch_sizes:
                for transform in transformations:
                    # Ažuriramo transformacije
                    train_dataset.dataset.transform = transform
                    val_dataset.dataset.transform = transform

                    dataloaders = {
                        'train': DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4),
                        'val': DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
                    }

                    dataset_sizes = {x: len(dataloaders[x].dataset) for x in ['train', 'val']}
                    class_names = full_train_dataset.label_to_idx.keys()

                    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

                    # Učitavamo predtreniran ResNet model
                    model_ft = models.resnet18(pretrained=True)
                    num_ftrs = model_ft.fc.in_features
                    model_ft.fc = nn.Linear(num_ftrs, len(class_names))
                    model_ft = model_ft.to(device)

                    criterion = nn.CrossEntropyLoss()

                    if opt == 'SGD':
                        optimizer_ft = optim.SGD(model_ft.parameters(), lr=lr, momentum=0.9)
                    elif opt == 'Adam':
                        optimizer_ft = optim.Adam(model_ft.parameters(), lr=lr)

                    scheduler = optim.lr_scheduler.StepLR(optimizer_ft, step_size=7, gamma=0.1)

                    print(f"Training model with lr={lr}, optimizer={opt}, batch_size={batch_size}, transform={transform}")
                    model_ft = train_model(model_ft, criterion, optimizer_ft, scheduler, dataloaders, dataset_sizes, device, num_epochs=num_epochs)

                    val_loss, val_acc = evaluate_model(model_ft, dataloaders['val'], criterion, device)
                    print(f"Validation Loss: {val_loss:.4f} Validation Accuracy: {val_acc:.4f}")

                    results.append({
                        'learning_rate': lr,
                        'optimizer': opt,
                        'batch_size': batch_size,
                        'transform': str(transform),
                        'val_loss': val_loss,
                        'val_acc': val_acc.item()
                    })

    # Spremamo rezultate u CSV
    keys = results[0].keys()
    with open('model_results.csv', 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(results)

    # Pronalaženje najboljeg modela
    best_model_params = sorted(results, key=lambda x: x['val_acc'], reverse=True)[0]
    print(f"Best model parameters: {best_model_params}")

    # Kreiramo dataset i dataloader za sve podatke
    full_train_dataset.transform = eval(best_model_params['transform'])
    full_val_dataset.transform = eval(best_model_params['transform'])

    full_train_loader = DataLoader(full_train_dataset, batch_size=best_model_params['batch_size'], shuffle=True, num_workers=4)
    full_val_loader = DataLoader(full_val_dataset, batch_size=best_model_params['batch_size'], shuffle=True, num_workers=4)
    full_dataloaders = {
        'train': full_train_loader,
        'val': full_val_loader
    }
    full_dataset_sizes = {x: len(full_dataloaders[x].dataset) for x in ['train', 'val']}

    # Treniramo konačni model s najboljim parametrima
    final_model = models.resnet18(pretrained=True)
    num_ftrs = final_model.fc.in_features
    final_model.fc = nn.Linear(num_ftrs, len(class_names))
    final_model = final_model.to(device)

    if best_model_params['optimizer'] == 'SGD':
        final_optimizer = optim.SGD(final_model.parameters(), lr=best_model_params['learning_rate'], momentum=0.9)
    elif best_model_params['optimizer'] == 'Adam':
        final_optimizer = optim.Adam(final_model.parameters(), lr=best_model_params['learning_rate'])

    final_scheduler = optim.lr_scheduler.StepLR(final_optimizer, step_size=7, gamma=0.1)

    print(f"Training final model with best parameters: {best_model_params}")
    final_model = train_model(final_model, criterion, final_optimizer, final_scheduler, full_dataloaders, full_dataset_sizes, device, num_epochs=num_epochs)

    # Evaluiramo konačni model
    final_train_loss, final_train_acc = evaluate_model(final_model, full_dataloaders['train'], criterion, device)
    final_val_loss, final_val_acc = evaluate_model(final_model, full_dataloaders['val'], criterion, device)

    print(f"Final Model Training Loss: {final_train_loss:.4f} Training Accuracy: {final_train_acc:.4f}")
    print(f"Final Model Validation Loss: {final_val_loss:.4f} Validation Accuracy: {final_val_acc:.4f}")

    # Spremamo finalni model
    torch.save(final_model.state_dict(), 'best_model.pth')
